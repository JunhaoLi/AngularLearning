import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { HeroDetailComponent } from './hero-detail.component';
import { of } from 'rxjs/internal/observable/of';
import { FormsModule } from '@angular/forms';
import { HeroService } from '../hero.service';

describe('HeroDetail', () => {
    let mockHeroservice;
    let mockLocation;
    let mockActivatedRoute;
    let fixture: ComponentFixture<HeroDetailComponent>;

    beforeEach(() => {
        mockHeroservice = jasmine.createSpyObj(['getHero', 'updateHero']);
        mockLocation = jasmine.createSpyObj(['back']);
        mockActivatedRoute = {
            snapshot: {
                paramMap: {
                    get: () => '3'
                }
            }
        };

        TestBed.configureTestingModule({
            imports: [FormsModule],
            declarations: [HeroDetailComponent],
            providers: [
                { provide: HeroService, useValue: mockHeroservice },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: Location, useValue: mockLocation }
            ]
        });

        fixture = TestBed.createComponent(HeroDetailComponent);

        mockHeroservice.getHero.and.returnValue(of({id: 3, name: 'SuperDude', strength: 100}));
    });

    it('should render hero name uppercase', () => {
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector('h2').textContent).toContain('SUPERDUDE');
    });
});
